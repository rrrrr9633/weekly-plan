-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: weekly_plan
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.22.04.3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companies` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--

LOCK TABLES `companies` WRITE;
/*!40000 ALTER TABLE `companies` DISABLE KEYS */;
INSERT INTO `companies` VALUES (1,'LIAONING_GUQI_DATA','辽宁谷器数据','ACTIVE','2026-08-17 02:40:02','2026-08-17 02:40:02'),(2,'TEST_DATA','测试展示公司','ACTIVE','2026-08-17 03:02:21','2026-08-17 03:02:21');
/*!40000 ALTER TABLE `companies` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `flyway_schema_history`
--

DROP TABLE IF EXISTS `flyway_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `flyway_schema_history` (
  `installed_rank` int NOT NULL,
  `version` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `script` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` int DEFAULT NULL,
  `installed_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `execution_time` int NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `flyway_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flyway_schema_history`
--

LOCK TABLES `flyway_schema_history` WRITE;
/*!40000 ALTER TABLE `flyway_schema_history` DISABLE KEYS */;
INSERT INTO `flyway_schema_history` VALUES (1,'1','create identity schema','SQL','V1__create_identity_schema.sql',-1426550106,'weekly_plan','2026-08-14 04:34:13',184,1),(2,'2','create project and week plan schema','SQL','V2__create_project_and_week_plan_schema.sql',-1952281101,'weekly_plan','2026-08-14 04:34:13',142,1),(3,'3','add week plan archive status','SQL','V3__add_week_plan_archive_status.sql',-794466057,'weekly_plan','2026-08-14 04:34:13',259,1),(4,'4','support multiple week plans and weekdays','SQL','V4__support_multiple_week_plans_and_weekdays.sql',-1193105181,'weekly_plan','2026-08-14 04:34:13',107,1),(5,'5','add week plan board position','SQL','V5__add_week_plan_board_position.sql',1803599314,'weekly_plan','2026-08-14 04:34:13',91,1),(6,'6','backfill user display names','SQL','V6__backfill_user_display_names.sql',-122789733,'weekly_plan','2026-08-16 19:37:43',40,1),(7,'7','add company tenant isolation','SQL','V7__add_company_tenant_isolation.sql',1990356048,'weekly_plan','2026-08-17 02:40:03',770,1),(8,'8','add week plan participants','SQL','V8__add_week_plan_participants.sql',1068969169,'weekly_plan','2026-08-17 08:05:14',205,1);
/*!40000 ALTER TABLE `flyway_schema_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assist_org` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `company_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_projects_company_code` (`company_id`,`code`),
  KEY `idx_projects_status` (`status`),
  KEY `idx_projects_company_status` (`company_id`,`status`),
  CONSTRAINT `fk_projects_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1,'001','二期诊断（初次入企）','二期诊断初次入企','陈浩然','ACTIVE','2026-08-14 06:28:35','2026-08-14 06:28:35',1),(11,'PARK-DATA-2026','智慧园区数据中台建设','整合园区业务数据，建设统一的数据资产与服务能力。','信息化建设办公室','ACTIVE','2026-08-17 03:12:59','2026-08-17 03:12:59',2),(12,'CITY-CMD-2026','城市运行指挥平台升级','提升城市事件协同处置和运行态势研判能力。','信息化建设办公室','ACTIVE','2026-08-17 03:12:59','2026-08-17 03:12:59',2),(13,'GOV-DATA-2026','政务数据治理专项','推进跨部门数据标准、质量治理与共享应用。','信息化建设办公室','ACTIVE','2026-08-17 03:13:00','2026-08-17 03:13:00',2),(14,'MOBILE-SVC-2026','企业服务移动端优化','优化企业服务事项的移动端办理与体验。','信息化建设办公室','ACTIVE','2026-08-17 03:13:00','2026-08-17 03:13:00',2),(15,'DATA-SEC-2026','数据安全与合规建设','完善数据分级分类、权限审计和合规管理体系。','信息化建设办公室','ACTIVE','2026-08-17 03:13:00','2026-08-17 03:13:00',2),(16,'002','客户交流','客户系统交流','陈浩然','ACTIVE','2026-08-17 08:47:46','2026-08-17 08:47:46',1),(17,'003','二期诊断（2、3次报告盖章）','企业诊断第二次第三次盖章任务','陈浩然','ACTIVE','2026-08-17 08:48:28','2026-08-17 08:48:28',1),(18,'004','一期诊断（2、3次报告盖章）','企业诊断第二次第三次盖章任务','陈浩然','ACTIVE','2026-08-17 08:48:38','2026-08-17 08:48:38',1),(19,'000','公共','其他项目','陈浩然','ACTIVE','2026-08-17 09:10:56','2026-08-17 09:10:56',1);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `refresh_tokens`
--

DROP TABLE IF EXISTS `refresh_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refresh_tokens` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `token_hash` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` timestamp NOT NULL,
  `revoked_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `token_hash` (`token_hash`),
  KEY `idx_refresh_tokens_user_expiry` (`user_id`,`expires_at`),
  CONSTRAINT `fk_refresh_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refresh_tokens`
--

LOCK TABLES `refresh_tokens` WRITE;
/*!40000 ALTER TABLE `refresh_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `refresh_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'ADMIN','总台管理员','2026-08-14 04:34:13'),(2,'USER','普通用户','2026-08-14 04:34:13'),(3,'SUPER_ADMIN','超级管理员','2026-08-17 02:40:02');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_code` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_hash` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `role_id` bigint NOT NULL,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `company_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_code` (`user_code`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_users_role_status` (`role_id`,`status`),
  KEY `idx_users_company_status` (`company_id`,`status`),
  CONSTRAINT `fk_users_company` FOREIGN KEY (`company_id`) REFERENCES `companies` (`id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (3,'U1786689701998','陈浩然','$2a$10$SM1Z01A1hHBQ0DlnhEfpWejFl4Ht7MyOPQA1u/Mz7pRRFKk0EMh2i','陈浩然',NULL,NULL,'ACTIVE',1,'2026-08-18 02:07:44','2026-08-14 06:41:42','2026-08-18 02:21:41',1),(19,'SUPER-001','rrrrr9633','$2a$10$.6gl4HvdE9ilMBbjlGpBje5kAI8O2HeTy7pNZ3dUiNvEUajWcpKlq','超级管理员',NULL,NULL,'ACTIVE',3,'2026-08-18 02:14:18','2026-08-17 02:51:42','2026-08-17 02:53:14',NULL),(40,'U1786936374730','zhangwei','$2a$10$0r7cjbvgC0H/PNbvKsBuRu3Oz/G5CoUfASSXb1nHFI7EiipoRoW2a','张伟',NULL,NULL,'ACTIVE',1,'2026-08-17 09:59:40','2026-08-17 03:12:55','2026-08-17 03:16:08',2),(41,'U1786936375515','liuming','$2a$10$KP6dEzOUz.5N2VRIdQKH9eaIzBtY/7ZSUZZVHHkDF2E3KRT.NN7se','刘明',NULL,NULL,'ACTIVE',2,'2026-08-17 03:16:59','2026-08-17 03:12:56','2026-08-17 03:17:08',2),(42,'U1786936375721','wangjing','$2a$10$ziBWwZLzjyxRyuyybfn6BuHnbVkZW60.ycwpubXdkdFPalBzzxlre','王静',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:56','2026-08-17 03:12:59',2),(43,'U1786936375919','chenlei','$2a$10$t0Z9SwdMc/wNFeMkHFHHdO5ffHEn6n5dE1IaHHLAX/Nf3EIw4XiqC','陈磊',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:56','2026-08-17 03:12:59',2),(44,'U1786936376096','zhaoxin','$2a$10$rhEqo/fvWsAUlcs.VKWHzOAf0dEL4tlufot8pkYNdm.HPK7iK3IwK','赵鑫',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:56','2026-08-17 03:12:59',2),(45,'U1786936376252','sunqian','$2a$10$lj4.4b1OhHMpG1mi04nfquteHrzfyDGGrJDkRm0oTph9vSZEJcW5q','孙倩',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:56','2026-08-17 03:12:59',2),(46,'U1786936376422','huangbo','$2a$10$SZBje2H78NSTXsTImA4Dtu1A/4d/RTVjz.CbeoIvyjFDTCdrUBhsK','黄博',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:57','2026-08-17 03:12:59',2),(47,'U1786936376596','zhouyan','$2a$10$dvSf1jQS8CvuN/7ZfpthleFr1sF7t6QCzx.sp/vxpRx.qok19wEyq','周燕',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:57','2026-08-17 03:12:59',2),(48,'U1786936376788','wujun','$2a$10$BIGDqlySh4ZZXKM85RWck.S1iSxNpy0SHL6kdHAgQnVMI/92q9dUG','吴军',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:57','2026-08-17 03:12:59',2),(49,'U1786936376973','xulili','$2a$10$THZznCrHDg/mwUqExK9aVOQV4Z62..3RCW6P/juOUkSXCqmcsSXHK','徐莉莉',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:57','2026-08-17 03:12:59',2),(50,'U1786936377160','gaocheng','$2a$10$klUiuaYjZkaCHNNYw45yZuZakknNL6R7.U82/HSr6a..a6sH/9O3C','高程',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:57','2026-08-17 03:12:59',2),(51,'U1786936377347','linna','$2a$10$sqidDgN3XvPHcKXmYbz62O.Dy.rd897dG0O1Hz9W4O5VjjwFycSzu','林娜',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:57','2026-08-17 03:12:59',2),(52,'U1786936377532','hepeng','$2a$10$nUpvx5CluxudDxaRGIagOO3ybKejMnsFcTrMAFQDqR5OtpDowQtgC','何鹏',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:58','2026-08-17 03:12:59',2),(53,'U1786936377702','yangfan','$2a$10$vm6BAWFuNwFCF9.jM.uPXOHIwCMowM3sEVd.J2KcWYdMj3r3aWvhe','杨帆',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:58','2026-08-17 03:12:59',2),(54,'U1786936377885','luoying','$2a$10$Cg2EoK/mkSG5ebbIEJ0DRu/vUo.iskIw4TwpNo/1aL5a3QVyN8qE.','罗颖',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:58','2026-08-17 03:12:59',2),(55,'U1786936378061','mawei','$2a$10$fbjY3POcobGjczO5dKHQhuNso.JIH6tPXrbxuACjCNwNLuva9sv9q','马伟',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:58','2026-08-17 03:12:59',2),(56,'U1786936378264','tangjie','$2a$10$9u34pVAaP72hVU7XNXy.EOli75oQOhOwOtNdULy7dI8h/nWgvScHO','唐杰',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:58','2026-08-17 03:12:59',2),(57,'U1786936378450','qiaoyu','$2a$10$2XhkSFsp.NGW1Fwp2nAif.Id4RnrHz0Jh8ivE8Bf0Kcy7MhUyXBXC','乔宇',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:59','2026-08-17 03:12:59',2),(58,'U1786936378670','dengchao','$2a$10$rgbI1QqbwqxEMPLA.6bCGOpAJXUUr4ajnzj3zldU.6DJGW/iR47py','邓超',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:59','2026-08-17 03:12:59',2),(59,'U1786936378868','fengxue','$2a$10$ZQPFWHVt/6ZWinpsP496h.hI1SlUHD/byCUpa86Lhh4pXYlnc7T2i','冯雪',NULL,NULL,'ACTIVE',2,NULL,'2026-08-17 03:12:59','2026-08-17 03:12:59',2),(64,'U1786959595076','18640339596','$2a$10$q/arfgR17n7A9.X56AzUD.uvcz3pHiE7gUuz.rej00mRjUypf4Tyq','谭天鸣',NULL,NULL,'ACTIVE',1,NULL,'2026-08-17 09:39:55','2026-08-18 02:21:19',1),(65,'U1786959601338','sxk','$2a$10$g3HOWMVSvKvoMjS0s2Zvj.BQQfEW8xScSdsKKVRMtXBlr2oct2Rvu','桑兴坤',NULL,NULL,'ACTIVE',1,NULL,'2026-08-17 09:40:01','2026-08-18 02:21:32',1),(66,'U1786959681285','陈露荷','$2a$10$BEaZPti2NYV1RDm1bs7/..MDJBtowSxULOOd/r.pykldFfoYrXS5q','陈露荷',NULL,NULL,'ACTIVE',1,NULL,'2026-08-17 09:41:21','2026-08-17 09:44:45',1),(67,'U1786959714449','fuxiaobo','$2a$10$lePTHWrF8AlerFkR9TPLzeweLaN9oLHJKtgnx3TguO3rkZOZJhrES','付晓博',NULL,NULL,'ACTIVE',1,'2026-08-17 09:57:12','2026-08-17 09:41:55','2026-08-18 02:21:28',1),(68,'U1786960030821','韩新盈','$2a$10$SfcsWgIYlBiwDyJWiOTAqO6ELnvqRCXVheREFZaiNVJnmIE9vxrBG','韩新盈',NULL,NULL,'ACTIVE',1,NULL,'2026-08-17 09:47:11','2026-08-17 10:36:00',1),(69,'U1786962734075','xy','$2a$10$Fm2ZZ6kllgjncrOwHDE00ulv7uxknx6K/UvYGwI5zTv/Qdy1EhRkC','徐野',NULL,NULL,'ACTIVE',1,NULL,'2026-08-17 10:32:14','2026-08-18 02:21:36',1),(70,'U1786962922928','李光宇','$2a$10$xXbk4Ac7AK.pSuSFTmhyIuvehpRY0fSpo2oi.AwbTJIz7u1SKx5WW','李光宇',NULL,NULL,'ACTIVE',1,NULL,'2026-08-17 10:35:23','2026-08-17 10:35:23',1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `week_plan_participants`
--

DROP TABLE IF EXISTS `week_plan_participants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `week_plan_participants` (
  `plan_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`plan_id`,`user_id`),
  KEY `idx_week_plan_participants_user` (`user_id`,`plan_id`),
  CONSTRAINT `fk_week_plan_participants_plan` FOREIGN KEY (`plan_id`) REFERENCES `week_plans` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_week_plan_participants_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `week_plan_participants`
--

LOCK TABLES `week_plan_participants` WRITE;
/*!40000 ALTER TABLE `week_plan_participants` DISABLE KEYS */;
INSERT INTO `week_plan_participants` VALUES (134,40,'2026-08-17 08:05:14'),(135,41,'2026-08-17 08:05:14'),(136,42,'2026-08-17 08:05:14'),(137,43,'2026-08-17 08:05:14'),(138,44,'2026-08-17 08:05:14'),(139,45,'2026-08-17 08:05:14'),(140,46,'2026-08-17 08:05:14'),(141,40,'2026-08-17 08:18:39'),(141,47,'2026-08-17 08:05:14'),(142,48,'2026-08-17 08:05:14'),(143,49,'2026-08-17 08:05:14'),(144,50,'2026-08-17 08:05:14'),(145,51,'2026-08-17 08:05:14'),(146,52,'2026-08-17 08:05:14'),(147,53,'2026-08-17 08:05:14'),(148,54,'2026-08-17 08:05:14'),(149,55,'2026-08-17 08:05:14'),(150,56,'2026-08-17 08:05:14'),(151,57,'2026-08-17 08:05:14'),(152,58,'2026-08-17 08:05:14'),(153,59,'2026-08-17 08:05:14'),(154,40,'2026-08-17 08:05:14'),(155,41,'2026-08-17 08:05:14'),(156,42,'2026-08-17 08:05:14'),(157,43,'2026-08-17 08:05:14'),(158,44,'2026-08-17 08:05:14'),(159,45,'2026-08-17 08:05:14'),(160,46,'2026-08-17 08:05:14'),(161,40,'2026-08-17 10:00:34'),(161,47,'2026-08-17 08:05:14'),(162,48,'2026-08-17 08:05:14'),(163,49,'2026-08-17 08:05:14'),(164,50,'2026-08-17 08:05:14'),(165,51,'2026-08-17 08:05:14'),(166,52,'2026-08-17 08:05:14'),(167,53,'2026-08-17 08:05:14'),(168,54,'2026-08-17 08:05:14'),(169,55,'2026-08-17 08:05:14'),(170,56,'2026-08-17 08:05:14'),(171,57,'2026-08-17 08:05:14'),(172,58,'2026-08-17 08:05:14'),(173,59,'2026-08-17 08:05:14'),(174,40,'2026-08-17 08:05:14'),(175,41,'2026-08-17 08:05:14'),(176,42,'2026-08-17 08:05:14'),(177,43,'2026-08-17 08:05:14'),(178,44,'2026-08-17 08:05:14'),(179,45,'2026-08-17 08:05:14'),(180,46,'2026-08-17 08:05:14'),(181,47,'2026-08-17 08:05:14'),(182,48,'2026-08-17 08:05:14'),(183,49,'2026-08-17 08:05:14'),(184,50,'2026-08-17 08:05:14'),(185,51,'2026-08-17 08:05:14'),(186,52,'2026-08-17 08:05:14'),(187,53,'2026-08-17 08:05:14'),(188,54,'2026-08-17 08:05:14'),(189,55,'2026-08-17 08:05:14'),(190,56,'2026-08-17 08:05:14'),(191,57,'2026-08-17 08:05:14'),(192,58,'2026-08-17 08:05:14'),(193,59,'2026-08-17 08:05:14'),(194,40,'2026-08-17 08:05:14'),(195,41,'2026-08-17 08:05:14'),(196,42,'2026-08-17 08:05:14'),(197,43,'2026-08-17 08:05:14'),(198,44,'2026-08-17 08:05:14'),(199,45,'2026-08-17 08:05:14'),(200,46,'2026-08-17 08:05:14'),(201,47,'2026-08-17 08:05:14'),(202,48,'2026-08-17 08:05:14'),(203,49,'2026-08-17 08:05:14'),(204,50,'2026-08-17 08:05:14'),(205,51,'2026-08-17 08:05:14'),(206,52,'2026-08-17 08:05:14'),(207,53,'2026-08-17 08:05:14'),(208,54,'2026-08-17 08:05:14'),(209,55,'2026-08-17 08:05:14'),(210,56,'2026-08-17 08:05:14'),(211,57,'2026-08-17 08:05:14'),(212,58,'2026-08-17 08:05:14'),(213,59,'2026-08-17 08:05:14'),(214,40,'2026-08-17 08:05:14'),(215,41,'2026-08-17 08:05:14'),(216,42,'2026-08-17 08:05:14'),(217,43,'2026-08-17 08:05:14'),(218,44,'2026-08-17 08:05:14'),(219,45,'2026-08-17 08:05:14'),(220,46,'2026-08-17 08:05:14'),(221,47,'2026-08-17 08:05:14'),(222,48,'2026-08-17 08:05:14'),(223,49,'2026-08-17 08:05:14'),(224,50,'2026-08-17 08:05:14'),(225,51,'2026-08-17 08:05:14'),(226,52,'2026-08-17 08:05:14'),(227,53,'2026-08-17 08:05:14'),(228,54,'2026-08-17 08:05:14'),(229,55,'2026-08-17 08:05:14'),(230,56,'2026-08-17 08:05:14'),(231,57,'2026-08-17 08:05:14'),(232,58,'2026-08-17 08:05:14'),(233,59,'2026-08-17 08:05:14'),(234,40,'2026-08-17 08:05:14'),(235,40,'2026-08-17 08:05:14'),(236,40,'2026-08-17 08:05:14'),(237,40,'2026-08-17 08:05:14'),(238,40,'2026-08-17 08:05:14'),(239,64,'2026-08-17 09:41:26'),(240,64,'2026-08-17 09:43:38'),(241,67,'2026-08-17 10:00:41'),(242,67,'2026-08-17 10:09:31'),(243,67,'2026-08-17 10:24:59'),(244,67,'2026-08-17 10:26:33'),(245,69,'2026-08-17 10:39:08'),(246,69,'2026-08-17 10:39:31'),(247,69,'2026-08-17 10:40:01'),(248,69,'2026-08-17 10:40:44'),(250,67,'2026-08-17 10:49:00'),(251,67,'2026-08-17 10:49:30'),(252,67,'2026-08-17 10:55:40'),(253,67,'2026-08-17 10:56:45'),(254,69,'2026-08-17 11:49:36'),(255,69,'2026-08-17 11:49:36'),(256,69,'2026-08-17 11:49:36'),(257,69,'2026-08-17 11:49:36'),(258,69,'2026-08-17 11:49:36'),(259,3,'2026-08-18 02:08:35');
/*!40000 ALTER TABLE `week_plan_participants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `week_plans`
--

DROP TABLE IF EXISTS `week_plans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `week_plans` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `project_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `assigned_by_user_id` bigint DEFAULT NULL,
  `year_number` int NOT NULL,
  `week_number` int NOT NULL,
  `content` varchar(4000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ACTIVE',
  `archived_at` timestamp NULL DEFAULT NULL,
  `weekday` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `board_position` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_week_plans_assigned_by` (`assigned_by_user_id`),
  KEY `idx_week_plans_year_week` (`year_number`,`week_number`),
  KEY `idx_week_plans_user_year_week` (`user_id`,`year_number`,`week_number`),
  KEY `idx_week_plans_user_status` (`user_id`,`status`),
  KEY `idx_week_plans_status_year_week` (`status`,`year_number`,`week_number`),
  KEY `idx_week_plans_user_project_week` (`user_id`,`project_id`,`year_number`,`week_number`),
  KEY `idx_week_plans_board_order` (`project_id`,`year_number`,`week_number`,`weekday`,`board_position`),
  CONSTRAINT `fk_week_plans_assigned_by` FOREIGN KEY (`assigned_by_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_week_plans_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`),
  CONSTRAINT `fk_week_plans_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=260 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `week_plans`
--

LOCK TABLES `week_plans` WRITE;
/*!40000 ALTER TABLE `week_plans` DISABLE KEYS */;
INSERT INTO `week_plans` VALUES (134,11,40,40,2026,34,'完成数据源接入清单核对并补充责任人','2026-08-17 03:13:00','2026-08-17 08:27:54','ARCHIVED','2026-08-17 08:27:54','MONDAY',NULL),(135,11,41,40,2026,34,'梳理指标口径差异并组织专题评审','2026-08-17 03:13:00','2026-08-17 03:13:00','ACTIVE',NULL,'TUESDAY',NULL),(136,11,42,40,2026,34,'推进接口联调并跟踪异常数据修复','2026-08-17 03:13:00','2026-08-17 03:13:00','ACTIVE',NULL,'WEDNESDAY',NULL),(137,11,43,40,2026,34,'编制阶段性成果材料并更新实施台账','2026-08-17 03:13:00','2026-08-17 03:13:00','ACTIVE',NULL,'THURSDAY',NULL),(138,11,44,40,2026,34,'开展用户访谈并确认本周需求优先级','2026-08-17 03:13:00','2026-08-17 03:13:00','ACTIVE',NULL,'FRIDAY',NULL),(139,11,45,40,2026,34,'完成原型评审问题整改并同步设计说明','2026-08-17 03:13:00','2026-08-17 03:13:00','ACTIVE',NULL,'MONDAY',NULL),(140,11,46,40,2026,34,'核验数据质量规则执行结果并提交报告','2026-08-17 03:13:00','2026-08-17 03:13:00','ACTIVE',NULL,'TUESDAY',NULL),(141,11,47,40,2026,34,'跟进开发任务进度并协调跨组依赖','2026-08-17 03:13:00','2026-08-17 03:13:00','ACTIVE',NULL,'WEDNESDAY',NULL),(142,11,48,40,2026,34,'整理会议纪要并推动待办事项闭环','2026-08-17 03:13:00','2026-08-17 03:13:00','ACTIVE',NULL,'THURSDAY',NULL),(143,11,49,40,2026,34,'完成权限配置核查和审计日志抽检','2026-08-17 03:13:00','2026-08-17 03:13:00','ACTIVE',NULL,'FRIDAY',NULL),(144,11,50,40,2026,34,'推进测试用例评审并补充边界场景','2026-08-17 03:13:00','2026-08-17 03:13:00','ACTIVE',NULL,'MONDAY',NULL),(145,11,51,40,2026,34,'复盘线上反馈并制定体验优化方案','2026-08-17 03:13:01','2026-08-17 03:13:01','ACTIVE',NULL,'TUESDAY',NULL),(146,11,52,40,2026,34,'更新项目风险清单并落实应对措施','2026-08-17 03:13:01','2026-08-17 03:13:01','ACTIVE',NULL,'WEDNESDAY',NULL),(147,11,53,40,2026,34,'完成发布前检查并编制回退预案','2026-08-17 03:13:01','2026-08-17 03:13:01','ACTIVE',NULL,'THURSDAY',NULL),(148,11,54,40,2026,34,'梳理主数据映射关系并提交确认单','2026-08-17 03:13:01','2026-08-17 03:13:01','ACTIVE',NULL,'FRIDAY',NULL),(149,11,55,40,2026,34,'跟进供应商交付物并完成验收记录','2026-08-17 03:13:01','2026-08-17 03:13:01','ACTIVE',NULL,'MONDAY',NULL),(150,11,56,40,2026,34,'开展专题培训并收集使用反馈','2026-08-17 03:13:01','2026-08-17 03:13:01','ACTIVE',NULL,'TUESDAY',NULL),(151,11,57,40,2026,34,'完成周报汇总和下周工作排期','2026-08-17 03:13:01','2026-08-17 03:13:01','ACTIVE',NULL,'WEDNESDAY',NULL),(152,11,58,40,2026,34,'核对接口性能指标并提出优化建议','2026-08-17 03:13:01','2026-08-17 03:13:01','ACTIVE',NULL,'THURSDAY',NULL),(153,11,59,40,2026,34,'协助业务部门完成上线准备工作','2026-08-17 03:13:01','2026-08-17 03:13:01','ACTIVE',NULL,'FRIDAY',NULL),(154,12,40,40,2026,34,'完成数据源接入清单核对并补充责任人','2026-08-17 03:13:01','2026-08-17 08:27:57','ARCHIVED','2026-08-17 08:27:57','MONDAY',2),(155,12,41,40,2026,34,'梳理指标口径差异并组织专题评审','2026-08-17 03:13:01','2026-08-17 06:35:01','ARCHIVED','2026-08-17 06:35:01','TUESDAY',0),(156,12,42,40,2026,34,'推进接口联调并跟踪异常数据修复','2026-08-17 03:13:01','2026-08-17 07:10:51','ACTIVE',NULL,'WEDNESDAY',1),(157,12,43,40,2026,34,'编制阶段性成果材料并更新实施台账','2026-08-17 03:13:01','2026-08-17 06:28:16','ACTIVE',NULL,'THURSDAY',NULL),(158,12,44,40,2026,34,'开展用户访谈并确认本周需求优先级','2026-08-17 03:13:01','2026-08-17 06:28:16','ACTIVE',NULL,'FRIDAY',NULL),(159,12,45,40,2026,34,'完成原型评审问题整改并同步设计说明','2026-08-17 03:13:01','2026-08-17 06:52:52','ACTIVE',NULL,'MONDAY',0),(160,12,46,40,2026,34,'核验数据质量规则执行结果并提交报告','2026-08-17 03:13:01','2026-08-17 06:28:29','ACTIVE',NULL,'TUESDAY',1),(161,12,47,40,2026,34,'跟进开发任务进度并协调跨组依赖','2026-08-17 03:13:01','2026-08-17 07:10:51','ACTIVE',NULL,'WEDNESDAY',0),(162,12,48,40,2026,34,'整理会议纪要并推动待办事项闭环','2026-08-17 03:13:02','2026-08-17 06:28:16','ACTIVE',NULL,'THURSDAY',NULL),(163,12,49,40,2026,34,'完成权限配置核查和审计日志抽检','2026-08-17 03:13:02','2026-08-17 06:28:16','ACTIVE',NULL,'FRIDAY',NULL),(164,12,50,40,2026,34,'推进测试用例评审并补充边界场景','2026-08-17 03:13:02','2026-08-17 06:52:52','ACTIVE',NULL,'MONDAY',3),(165,12,51,40,2026,34,'复盘线上反馈并制定体验优化方案','2026-08-17 03:13:02','2026-08-17 06:28:29','ACTIVE',NULL,'TUESDAY',3),(166,12,52,40,2026,34,'更新项目风险清单并落实应对措施','2026-08-17 03:13:02','2026-08-17 07:10:51','ACTIVE',NULL,'WEDNESDAY',3),(167,12,53,40,2026,34,'完成发布前检查并编制回退预案','2026-08-17 03:13:02','2026-08-17 06:28:16','ACTIVE',NULL,'THURSDAY',NULL),(168,12,54,40,2026,34,'梳理主数据映射关系并提交确认单','2026-08-17 03:13:02','2026-08-17 06:28:16','ACTIVE',NULL,'FRIDAY',NULL),(169,12,55,40,2026,34,'跟进供应商交付物并完成验收记录','2026-08-17 03:13:02','2026-08-17 06:52:52','ACTIVE',NULL,'MONDAY',1),(170,12,56,40,2026,34,'开展专题培训并收集使用反馈','2026-08-17 03:13:02','2026-08-17 06:28:29','ACTIVE',NULL,'TUESDAY',2),(171,12,57,40,2026,34,'完成周报汇总和下周工作排期','2026-08-17 03:13:02','2026-08-17 07:10:51','ACTIVE',NULL,'WEDNESDAY',2),(172,12,58,40,2026,34,'核对接口性能指标并提出优化建议','2026-08-17 03:13:02','2026-08-17 06:28:16','ACTIVE',NULL,'THURSDAY',NULL),(173,12,59,40,2026,34,'协助业务部门完成上线准备工作','2026-08-17 03:13:02','2026-08-17 06:28:16','ACTIVE',NULL,'FRIDAY',NULL),(174,13,40,40,2026,34,'完成数据源接入清单核对并补充责任人','2026-08-17 03:13:02','2026-08-17 08:28:02','ARCHIVED','2026-08-17 08:28:02','MONDAY',NULL),(175,13,41,40,2026,34,'梳理指标口径差异并组织专题评审','2026-08-17 03:13:02','2026-08-17 03:13:02','ACTIVE',NULL,'TUESDAY',NULL),(176,13,42,40,2026,34,'推进接口联调并跟踪异常数据修复','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'WEDNESDAY',NULL),(177,13,43,40,2026,34,'编制阶段性成果材料并更新实施台账','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'THURSDAY',NULL),(178,13,44,40,2026,34,'开展用户访谈并确认本周需求优先级','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'FRIDAY',NULL),(179,13,45,40,2026,34,'完成原型评审问题整改并同步设计说明','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'MONDAY',NULL),(180,13,46,40,2026,34,'核验数据质量规则执行结果并提交报告','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'TUESDAY',NULL),(181,13,47,40,2026,34,'跟进开发任务进度并协调跨组依赖','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'WEDNESDAY',NULL),(182,13,48,40,2026,34,'整理会议纪要并推动待办事项闭环','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'THURSDAY',NULL),(183,13,49,40,2026,34,'完成权限配置核查和审计日志抽检','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'FRIDAY',NULL),(184,13,50,40,2026,34,'推进测试用例评审并补充边界场景','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'MONDAY',NULL),(185,13,51,40,2026,34,'复盘线上反馈并制定体验优化方案','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'TUESDAY',NULL),(186,13,52,40,2026,34,'更新项目风险清单并落实应对措施','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'WEDNESDAY',NULL),(187,13,53,40,2026,34,'完成发布前检查并编制回退预案','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'THURSDAY',NULL),(188,13,54,40,2026,34,'梳理主数据映射关系并提交确认单','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'FRIDAY',NULL),(189,13,55,40,2026,34,'跟进供应商交付物并完成验收记录','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'MONDAY',NULL),(190,13,56,40,2026,34,'开展专题培训并收集使用反馈','2026-08-17 03:13:03','2026-08-17 03:13:03','ACTIVE',NULL,'TUESDAY',NULL),(191,13,57,40,2026,34,'完成周报汇总和下周工作排期','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'WEDNESDAY',NULL),(192,13,58,40,2026,34,'核对接口性能指标并提出优化建议','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'THURSDAY',NULL),(193,13,59,40,2026,34,'协助业务部门完成上线准备工作','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'FRIDAY',NULL),(194,14,40,40,2026,34,'完成数据源接入清单核对并补充责任人','2026-08-17 03:13:04','2026-08-17 08:28:05','ARCHIVED','2026-08-17 08:28:05','MONDAY',NULL),(195,14,41,40,2026,34,'梳理指标口径差异并组织专题评审','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'TUESDAY',NULL),(196,14,42,40,2026,34,'推进接口联调并跟踪异常数据修复','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'WEDNESDAY',NULL),(197,14,43,40,2026,34,'编制阶段性成果材料并更新实施台账','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'THURSDAY',NULL),(198,14,44,40,2026,34,'开展用户访谈并确认本周需求优先级','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'FRIDAY',NULL),(199,14,45,40,2026,34,'完成原型评审问题整改并同步设计说明','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'MONDAY',NULL),(200,14,46,40,2026,34,'核验数据质量规则执行结果并提交报告','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'TUESDAY',NULL),(201,14,47,40,2026,34,'跟进开发任务进度并协调跨组依赖','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'WEDNESDAY',NULL),(202,14,48,40,2026,34,'整理会议纪要并推动待办事项闭环','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'THURSDAY',NULL),(203,14,49,40,2026,34,'完成权限配置核查和审计日志抽检','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'FRIDAY',NULL),(204,14,50,40,2026,34,'推进测试用例评审并补充边界场景','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'MONDAY',NULL),(205,14,51,40,2026,34,'复盘线上反馈并制定体验优化方案','2026-08-17 03:13:04','2026-08-17 03:13:04','ACTIVE',NULL,'TUESDAY',NULL),(206,14,52,40,2026,34,'更新项目风险清单并落实应对措施','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'WEDNESDAY',NULL),(207,14,53,40,2026,34,'完成发布前检查并编制回退预案','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'THURSDAY',NULL),(208,14,54,40,2026,34,'梳理主数据映射关系并提交确认单','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'FRIDAY',NULL),(209,14,55,40,2026,34,'跟进供应商交付物并完成验收记录','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'MONDAY',NULL),(210,14,56,40,2026,34,'开展专题培训并收集使用反馈','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'TUESDAY',NULL),(211,14,57,40,2026,34,'完成周报汇总和下周工作排期','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'WEDNESDAY',NULL),(212,14,58,40,2026,34,'核对接口性能指标并提出优化建议','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'THURSDAY',NULL),(213,14,59,40,2026,34,'协助业务部门完成上线准备工作','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'FRIDAY',NULL),(214,15,40,40,2026,34,'完成数据源接入清单核对并补充责任人','2026-08-17 03:13:05','2026-08-17 08:27:28','ACTIVE',NULL,'MONDAY',NULL),(215,15,41,40,2026,34,'梳理指标口径差异并组织专题评审','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'TUESDAY',NULL),(216,15,42,40,2026,34,'推进接口联调并跟踪异常数据修复','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'WEDNESDAY',NULL),(217,15,43,40,2026,34,'编制阶段性成果材料并更新实施台账','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'THURSDAY',NULL),(218,15,44,40,2026,34,'开展用户访谈并确认本周需求优先级','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'FRIDAY',NULL),(219,15,45,40,2026,34,'完成原型评审问题整改并同步设计说明','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'MONDAY',NULL),(220,15,46,40,2026,34,'核验数据质量规则执行结果并提交报告','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'TUESDAY',NULL),(221,15,47,40,2026,34,'跟进开发任务进度并协调跨组依赖','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'WEDNESDAY',NULL),(222,15,48,40,2026,34,'整理会议纪要并推动待办事项闭环','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'THURSDAY',NULL),(223,15,49,40,2026,34,'完成权限配置核查和审计日志抽检','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'FRIDAY',NULL),(224,15,50,40,2026,34,'推进测试用例评审并补充边界场景','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'MONDAY',NULL),(225,15,51,40,2026,34,'复盘线上反馈并制定体验优化方案','2026-08-17 03:13:05','2026-08-17 03:13:05','ACTIVE',NULL,'TUESDAY',NULL),(226,15,52,40,2026,34,'更新项目风险清单并落实应对措施','2026-08-17 03:13:06','2026-08-17 03:13:06','ACTIVE',NULL,'WEDNESDAY',NULL),(227,15,53,40,2026,34,'完成发布前检查并编制回退预案','2026-08-17 03:13:06','2026-08-17 03:13:06','ACTIVE',NULL,'THURSDAY',NULL),(228,15,54,40,2026,34,'梳理主数据映射关系并提交确认单','2026-08-17 03:13:06','2026-08-17 03:13:06','ACTIVE',NULL,'FRIDAY',NULL),(229,15,55,40,2026,34,'跟进供应商交付物并完成验收记录','2026-08-17 03:13:06','2026-08-17 03:13:06','ACTIVE',NULL,'MONDAY',NULL),(230,15,56,40,2026,34,'开展专题培训并收集使用反馈','2026-08-17 03:13:06','2026-08-17 03:13:06','ACTIVE',NULL,'TUESDAY',NULL),(231,15,57,40,2026,34,'完成周报汇总和下周工作排期','2026-08-17 03:13:06','2026-08-17 03:13:06','ACTIVE',NULL,'WEDNESDAY',NULL),(232,15,58,40,2026,34,'核对接口性能指标并提出优化建议','2026-08-17 03:13:06','2026-08-17 03:13:06','ACTIVE',NULL,'THURSDAY',NULL),(233,15,59,40,2026,34,'协助业务部门完成上线准备工作','2026-08-17 03:13:06','2026-08-17 03:13:06','ACTIVE',NULL,'FRIDAY',NULL),(234,12,40,NULL,2026,34,'跟踪项目1的进展','2026-08-17 03:29:45','2026-08-17 06:52:52','ACTIVE',NULL,'MONDAY',4),(235,12,40,NULL,2026,34,'跟踪回款','2026-08-17 03:31:02','2026-08-17 06:28:29','ACTIVE',NULL,'TUESDAY',4),(236,12,40,NULL,2026,34,'跟踪项目进度','2026-08-17 03:31:02','2026-08-17 07:10:51','ACTIVE',NULL,'WEDNESDAY',4),(237,12,40,NULL,2026,34,'打电话给大庆','2026-08-17 03:32:05','2026-08-17 06:28:16','ACTIVE',NULL,'PENDING',NULL),(238,12,40,NULL,2026,34,'看看','2026-08-17 03:46:21','2026-08-17 08:27:50','ACTIVE',NULL,'THURSDAY',NULL),(239,19,64,NULL,2026,37,'新东方项目进度监控，与开发详细讨论功能实现方案','2026-08-17 09:41:26','2026-08-17 09:45:03','ARCHIVED','2026-08-17 09:45:03','MONDAY',NULL),(240,19,64,NULL,2026,37,'1-7批验收项目佐证ppt编写','2026-08-17 09:43:38','2026-08-17 09:43:38','ACTIVE',NULL,'TUESDAY',NULL),(241,19,67,NULL,2026,34,'大连联通项目沟通交流\n联系供应商齐总，软硬一体报价；','2026-08-17 10:00:41','2026-08-18 01:56:53','ACTIVE',NULL,'MONDAY',1),(242,19,67,NULL,2026,34,'阿诺德能源与供应商沟通报价。','2026-08-17 10:09:31','2026-08-18 01:56:53','ACTIVE',NULL,'MONDAY',0),(243,16,67,NULL,2026,34,'中街冰点交流与老板汇报','2026-08-17 10:24:59','2026-08-17 10:24:59','ACTIVE',NULL,'WEDNESDAY',NULL),(244,19,67,NULL,2026,34,'联系抚顺制衣厂项目方案和报价\n方案已出，报价待出；','2026-08-17 10:26:33','2026-08-18 01:56:53','ACTIVE',NULL,'MONDAY',2),(245,19,69,NULL,2026,34,'亚新科案例材料整理，医疗盖章预约','2026-08-17 10:39:08','2026-08-17 10:39:08','ACTIVE',NULL,'TUESDAY',NULL),(246,19,69,NULL,2026,34,'中街冰点交流','2026-08-17 10:39:31','2026-08-17 10:39:31','ACTIVE',NULL,'WEDNESDAY',NULL),(247,19,69,NULL,2026,34,'吉林出差纳海交流','2026-08-17 10:40:01','2026-08-17 10:40:22','ACTIVE',NULL,'THURSDAY',NULL),(248,19,69,NULL,2026,34,'抚顺制衣厂方案交流','2026-08-17 10:40:44','2026-08-17 10:40:44','ACTIVE',NULL,'FRIDAY',NULL),(250,16,67,NULL,2026,34,'出差吉林交流2个项目','2026-08-17 10:49:00','2026-08-17 10:49:00','ACTIVE',NULL,'PENDING',NULL),(251,1,67,NULL,2026,34,'安排沈阳2家入企诊断工作','2026-08-17 10:49:30','2026-08-17 10:49:30','ACTIVE',NULL,'PENDING',NULL),(252,19,67,NULL,2026,34,'报送先进制造业集群重点推广创新成果的通知','2026-08-17 10:55:40','2026-08-17 10:55:40','ACTIVE',NULL,'TUESDAY',NULL),(253,19,67,NULL,2026,34,'大庆赢春项目合作推动，给出新万通的满足数字化车间内容','2026-08-17 10:56:45','2026-08-17 10:56:45','ACTIVE',NULL,'PENDING',NULL),(254,19,69,3,2026,34,'大庆新万通数字化车间要求对标分析整理；','2026-08-17 11:49:36','2026-08-18 01:56:53','ACTIVE',NULL,'MONDAY',3),(255,19,69,3,2026,34,'亚新科项目情况---内部交流。','2026-08-17 11:49:36','2026-08-18 01:56:53','ACTIVE',NULL,'MONDAY',4),(256,19,69,3,2026,34,'抚顺丰源制衣厂设备定位---电信交流；','2026-08-17 11:49:36','2026-08-18 01:56:53','ACTIVE',NULL,'MONDAY',5),(257,19,69,3,2026,34,'辽宁爱湾思新能源、爱斯希姆(大连)精密制造、奇瑞(大连)汽车零部件产业园---联通线上交流；','2026-08-17 11:49:36','2026-08-18 01:56:53','ACTIVE',NULL,'MONDAY',6),(258,19,69,3,2026,34,'沈阳顶峰机电诊断报告编写；','2026-08-17 11:49:36','2026-08-18 01:56:53','ACTIVE',NULL,'MONDAY',7),(259,19,3,NULL,2026,34,'测试','2026-08-18 02:08:35','2026-08-18 02:08:35','ACTIVE',NULL,'PENDING',NULL);
/*!40000 ALTER TABLE `week_plans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'weekly_plan'
--

--
-- Dumping routines for database 'weekly_plan'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-18  2:22:46
